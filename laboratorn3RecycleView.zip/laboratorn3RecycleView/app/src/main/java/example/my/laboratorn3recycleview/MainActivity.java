package example.my.laboratorn3recycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        List<Picture> pictures = new ArrayList<>();
        pictures.add(new Picture("Иван Айвазовский",
                "Девятый вал",
                "«Девятый вал» — одна из самых знаменитых картин российского художника-мариниста армянского происхождения Ивана Айвазовского, хранится в Русском музее в Санкт-Петербурге. Написана в 1850 году. Живописец изображает море после очень сильного ночного шторма и людей, потерпевших кораблекрушение.",
                R.drawable.picture1));
        pictures.add(new Picture("Сальвадор Дали",
                "Постоянство памяти",
                "«Постоянство памяти» — одна из самых известных картин художника Сальвадора Дали. Находится в Музее современного искусства в Нью-Йорке с 1934 года. Известна также как «Мягкие часы», «Твердость памяти» или «Стойкость памяти» или «Течение времени» или «Время».",
                R.drawable.picture2));
        pictures.add(new Picture("Исаак Левитан",
                "Золотая осень",
                "«Золотая осень» — пейзаж русского художника Исаака Левитана, написанный в 1895 году. Принадлежит Государственной Третьяковской галерее. Размер картины — 82 × 126 см. Левитан начал работу над картиной осенью 1895 года, когда он жил в усадьбе Горка в Тверской губернии; там же были написаны первые этюды.",
                R.drawable.picture3));
        pictures.add(new Picture("Иван Шишкин",
                "Утро в сосновом лесу",
                "«Утро в сосновом лесу» — картина русских художников И. И. Шишкина и К. А. Савицкого. Савицкий написал медведей, но коллекционер П. М. Третьяков стёр его подпись, так что автором картины часто указывается один Шишкин.",
                R.drawable.picture4));

        RecyclerView rv = findViewById(R.id.list);
        rv.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rv.setLayoutManager(layoutManager);

        rv.setAdapter(new MyAdapter(pictures, this));

    }
}
