package example.my.laboratorn3recycleview;

public class Picture {
    private String author;
    private String title;
    private String information;
    private int imageId;

    //конструктор
    public Picture(String author,String title, String information, int imageId) {
        this.author = author;
        this.title = title;
        this.information = information;
        this.imageId = imageId;
    }

    //геттеры и сеттеры
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String information) {
        this.information = information;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
}
