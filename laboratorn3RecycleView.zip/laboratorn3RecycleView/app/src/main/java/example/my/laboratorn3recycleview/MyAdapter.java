package example.my.laboratorn3recycleview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class MyAdapter extends RecyclerView.Adapter<MyAdapter.PictureViewHolder> {

    private List<Picture> list;

    public MyAdapter(List<Picture> list, Context context) {
        this.list = list;
    }

    @NonNull
    @Override
    public PictureViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.card_item, viewGroup, false);
        v.getBackground().setAlpha(0);
        PictureViewHolder holder = new PictureViewHolder(v);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PictureViewHolder pictureViewHolder, int i) {
        pictureViewHolder.image.setImageResource(list.get(i).getImageId());
        pictureViewHolder.text.setText(list.get(i).getTitle());
    }

    @Override
    public int getItemCount() { //метод getItemCount вернет количество элементов, присутствующих в данных.
        return list.size();
    }

    public static class PictureViewHolder extends RecyclerView.ViewHolder {

        public ImageView image;
        public TextView text;

        public PictureViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.imageView);
            text = itemView.findViewById(R.id.textView);
        }
    }
}